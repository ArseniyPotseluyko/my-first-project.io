﻿using System;

class Program
{
    static void Main()
    {
        int number = 80;
        while (number >= 10)
        {
            Console.WriteLine(number);
            number -= 2;
        }
    }
}
