﻿using System;

class Program
{
    static void Main()
    {
        for (int number = 80; number >= 10; number -= 2)
        {
            Console.WriteLine(number);
        }
    }
}
